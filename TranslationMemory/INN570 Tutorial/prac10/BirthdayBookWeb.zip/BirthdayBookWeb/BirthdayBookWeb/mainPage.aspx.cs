﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Globalization;  
using System.Threading;


namespace BirthdayBookWeb
{
    public partial class mainPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                string[] languages = HttpContext.Current.Request.UserLanguages;

                DataTable dt = new DataTable();
                dt.Columns.Add("Name", typeof(String));
                dt.Columns.Add("Date", typeof(DateTime));
                dt.Columns.Add("Cost", typeof(System.Decimal));

                //add an initial entry to the birthday book
                DataRow workRow = dt.NewRow();
                workRow[0] = "[Example]"; 
                workRow[1] = DateTime.Now;
                workRow[2] = 0;
                dt.Rows.Add(workRow);
               
                Session["TaskTable"] = dt;
                BindData();

                #region Display culture list
                CultureInfo[] langList = CultureInfo.GetCultures(CultureTypes.AllCultures);

                String[] lang_names = new String[langList.Length];
                int j = 0;
                //get names of all cultures
                foreach (CultureInfo ci in langList)
                {
                    lang_names[j] = ci.Name + " " + ci.DisplayName;
                    j++;
                }

                Array.Sort(lang_names);//sort culture names
                int requiredCulture = 0;
                j = 0;
                foreach (String s in lang_names)
                {
                    DropDownList1.Items.Add(s);
                    if (Thread.CurrentThread.CurrentCulture.Name == s.Split(' ')[0]) //find the culture requested by browser
                        requiredCulture = j;
                    j++;
                }

                DropDownList1.SelectedIndex = requiredCulture;
                #endregion
            }
            else
            {
                int spaceIndex = DropDownList1.SelectedValue.ToString().IndexOf(" ");
                string CultureName = DropDownList1.SelectedValue.ToString().Substring(0, spaceIndex);
                Thread.CurrentThread.CurrentCulture = new CultureInfo(CultureName);
            }
        }


        //Edit selected entry
        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            string aaa = ((Label)GridView1.Rows[e.NewEditIndex].FindControl("lbldate")).Text;
            DateTime OldDate = Convert.ToDateTime(((Label)GridView1.Rows[e.NewEditIndex].FindControl("lbldate")).Text, CultureInfo.CurrentCulture);
            GridView1.EditIndex = e.NewEditIndex;
            BindData();
            ((TextBox)GridView1.Rows[e.NewEditIndex].FindControl("edtcost")).Attributes.Add("OnKeyPress", "txtKeyNumber();");
            ((System.Web.UI.WebControls.TextBox)GridView1.Rows[e.NewEditIndex].FindControl("edtdate")).Text = OldDate.ToString("d");
            Button1.Enabled = false;
        }

        //update a selected entry in the birthday book 
        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                if (e.NewValues["Name"] == null || e.NewValues["Cost"] == null)
                {
                    GridView1_RowCancelingEdit(this, new GridViewCancelEditEventArgs(e.RowIndex));
                }
                else
                {
                    //GridViewRow row = GridView1.Rows[e.RowIndex]; 
                    //get input data for the new entry
                    string newName = e.NewValues["Name"].ToString();
                    DateTime newDate = Convert.ToDateTime(((System.Web.UI.WebControls.TextBox)GridView1.Rows[e.RowIndex].FindControl("edtdate")).Text);
                    Decimal newCost = Convert.ToDecimal(e.NewValues["Cost"].ToString());

                    DataTable dt = new DataTable(); //create a table
                    dt.Columns.Add("Name", typeof(String));
                    dt.Columns.Add("Date", typeof(DateTime));
                    dt.Columns.Add("Cost", typeof(System.Decimal));
                    DataRow workRow;
                    for (int i = 0; i < GridView1.Rows.Count; i++)//go through all existing entries or rows
                    {
                        workRow = dt.NewRow();
                        if (i == e.RowIndex) //selected row, add new data
                        {
                            workRow[0] = newName;
                            workRow[1] = newDate;
                            workRow[2] = newCost;
                        }
                        else //otherwise keep the existing data
                        {
                            workRow[0] = ((Label)GridView1.Rows[i].FindControl("lblTitle")).Text;
                            workRow[1] = Convert.ToDateTime(((Label)GridView1.Rows[i].FindControl("lbldate")).Text);
                            string ass = ((Label)GridView1.Rows[i].FindControl("lblCost")).Text;
                            System.Decimal dec = decimal.Parse(ass, NumberStyles.Any, Thread.CurrentThread.CurrentCulture);
                            workRow[2] = dec;
                        }
                        dt.Rows.Add(workRow);//add the entry to the table
                    }
                    GridView1.EditIndex = -1;
                    Session["TaskTable"] = dt;
                    BindData();
                }
            }
            catch (Exception)
            {
                GridView1.EditIndex = -1;
                BindData();
            }
            Button1.Enabled = true;
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            BindData();
            Button1.Enabled = true;
        }

        private void BindData()
        {
            GridView1.DataSource = Session["TaskTable"];
            GridView1.DataBind();
        }

        //Delete an existing row
        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Name", typeof(String));
            dt.Columns.Add("Date", typeof(DateTime));
            dt.Columns.Add("Cost", typeof(System.Decimal));
            DataRow workRow;
            for (int i = 0; i < GridView1.Rows.Count; i++) //read all existing entries or rows and add to table dt except for the selected row
            {
                if (i != e.RowIndex)
                {
                    workRow = dt.NewRow();
                    workRow[0] = ((Label)GridView1.Rows[i].FindControl("lblTitle")).Text;
                    workRow[1] = Convert.ToDateTime(((Label)GridView1.Rows[i].FindControl("lbldate")).Text);
                    string oldCost = ((Label)GridView1.Rows[i].FindControl("lblCost")).Text;
                    System.Decimal dec = decimal.Parse(oldCost, NumberStyles.Any, Thread.CurrentThread.CurrentCulture);
                    workRow[2] = dec;
                    dt.Rows.Add(workRow);
                }
            }
            GridView1.EditIndex = -1;
            Session["TaskTable"] = dt;
            BindData();
        }

        //to add a new birthday entry (row)
        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Name", typeof(String));
            dt.Columns.Add("Date", typeof(DateTime));
            dt.Columns.Add("Cost", typeof(Decimal));
            DataRow workRow;
            for (int i = 0; i < GridView1.Rows.Count; i++)//read existing entries and add to table dt
            {
                workRow = dt.NewRow();
                workRow[0] = ((Label)GridView1.Rows[i].FindControl("lblTitle")).Text;
                workRow[1] = Convert.ToDateTime(((Label)GridView1.Rows[i].FindControl("lbldate")).Text);
                string oldCost = ((Label)GridView1.Rows[i].FindControl("lblCost")).Text;
                System.Decimal dec = decimal.Parse(oldCost, NumberStyles.Any, Thread.CurrentThread.CurrentCulture);
                workRow[2] = dec;
                dt.Rows.Add(workRow);
            }
            workRow = dt.NewRow();//create a new row 
            workRow[0] = "Name " + (GridView1.Rows.Count).ToString();//add data to the new row 
            workRow[1] = DateTime.Now;
            workRow[2] = ((Decimal)500);
            dt.Rows.Add(workRow);//add the new row to the table
            GridView1.EditIndex = GridView1.Rows.Count;
            Session["TaskTable"] = dt;
            BindData();
            ((System.Web.UI.WebControls.TextBox)GridView1.Rows[GridView1.Rows.Count - 1].FindControl("edtdate")).Text = (DateTime.Now).ToString("d");
            Button1.Enabled = false;
        }


        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            int spaceIndex = DropDownList1.SelectedValue.ToString().IndexOf(" ");
            string CultureName = DropDownList1.SelectedValue.ToString().Substring(0, spaceIndex);
            Thread.CurrentThread.CurrentCulture = new CultureInfo(CultureName);
            Thread.CurrentThread.CurrentUICulture = new CultureInfo(CultureName);
            string aa = Thread.CurrentThread.CurrentUICulture.Name;
            BindData();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}